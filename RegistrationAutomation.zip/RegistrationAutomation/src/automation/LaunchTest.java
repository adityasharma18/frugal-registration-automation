package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.nio.file.Files;
import java.time.Duration;

public class LaunchTest {

    public static void main(String[] args) throws Exception {

        // 🔹 ChromeDriver path
        System.setProperty(
                "webdriver.chrome.driver",
                "C:\\Program Files\\chromedriver-win64\\chromedriver.exe"
        );

        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        // 🔹 Open application
        driver.get("file:///C:/Users/adity/Desktop/frugal/index.html");


        System.out.println("Page Title: " + driver.getTitle());
        System.out.println("Page URL: " + driver.getCurrentUrl());

        // ===============================
        // NEGATIVE TEST CASE
        // ===============================
        System.out.println("Running Negative Test Case...");

        driver.findElement(By.id("firstName")).sendKeys("Aditya");
        // lastName intentionally skipped
        driver.findElement(By.id("email")).sendKeys("test@gmail.com");
        driver.findElement(By.id("phone")).sendKeys("9876543210");
        driver.findElement(By.id("password")).sendKeys("Test@123");
        driver.findElement(By.id("confirmPassword")).sendKeys("Test@123");
        driver.findElement(By.xpath("//input[@value='Male']")).click();
        driver.findElement(By.id("terms")).click();

        driver.findElement(By.tagName("button")).click();

        WebElement lastNameError =
                driver.findElement(By.id("lastNameError"));

        if (lastNameError.isDisplayed()) {
            System.out.println("Negative Test Passed: Error displayed");
        }

        takeScreenshot(driver, "error-state.png");

        // ===============================
        // POSITIVE TEST CASE
        // ===============================
        System.out.println("Running Positive Test Case...");

        driver.navigate().refresh();

        driver.findElement(By.id("firstName")).sendKeys("Aditya");
        driver.findElement(By.id("lastName")).sendKeys("Sharma");
        driver.findElement(By.id("email")).sendKeys("test@gmail.com");
        driver.findElement(By.id("phone")).sendKeys("9876543210");
        driver.findElement(By.id("password")).sendKeys("Test@123");
        driver.findElement(By.id("confirmPassword")).sendKeys("Test@123");
        driver.findElement(By.xpath("//input[@value='Male']")).click();
        driver.findElement(By.id("terms")).click();

        driver.findElement(By.tagName("button")).click();

        System.out.println("Positive Test Passed: Form submitted");

        takeScreenshot(driver, "success-state.png");

        driver.quit();
        System.out.println("Automation Completed Successfully");
    }

    // ===============================
    // Screenshot Method
    // ===============================
    public static void takeScreenshot(WebDriver driver, String fileName) throws Exception {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Files.copy(src.toPath(), new File(fileName).toPath());
    }
}
